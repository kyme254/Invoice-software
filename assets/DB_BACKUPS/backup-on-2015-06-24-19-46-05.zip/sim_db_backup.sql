#
# TABLE STRUCTURE FOR: calendar
#

DROP TABLE IF EXISTS calendar;

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `data` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-04-17', 'school function', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-04-23', 'movie lunch ', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-04-24', 'marriage function', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-05-15', 'jai fooolw uop', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-05-23', 'film function rama naidu stduio , 3 leD VANS REQUIRED', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-05-31', 'HTDYCUGCU', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-08-15', 'flim event', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-08-01', 'flim events', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-08-08', 'cultural events', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-08-21', 'uuuu', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-09-03', 'k', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-09-06', 'Me at go', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-11-14', 'how ar eyou ', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2014-11-11', 'hello', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-02-28', 'event name tkr coleege ', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-01-01', 'annual day', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-01-08', 'sankranti holidays', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-04-24', 'jhgug', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-06-01', 'tst', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-06-05', 'okok\n', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-06-04', 'testing', 1);
INSERT INTO calendar (`date`, `data`, `user_id`) VALUES ('2015-06-03', 'Test', 1);


#
# TABLE STRUCTURE FOR: company
#

DROP TABLE IF EXISTS company;

CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `cf1` varchar(255) NOT NULL,
  `cf2` varchar(255) NOT NULL,
  `cf3` varchar(255) NOT NULL,
  `cf4` varchar(255) NOT NULL,
  `cf5` varchar(255) NOT NULL,
  `cf6` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO company (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (1, 'Tam invoice manager 2.0 ', 'Met corp IT Solutions Pvt Ltd', 'abc', '', '', '', '', '', 'My Business Address', 'hyderabad', 'Stelangana', '46050', 'India', '+91 9985922778', 'varun7king@gmail.com');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) DEFAULT '-',
  `cf1` varchar(255) DEFAULT '-',
  `cf2` varchar(255) DEFAULT '-',
  `cf3` varchar(255) DEFAULT '-',
  `cf4` varchar(255) DEFAULT '-',
  `cf5` varchar(255) DEFAULT '-',
  `cf6` varchar(255) DEFAULT '-',
  `address` varchar(255) DEFAULT '-',
  `city` varchar(55) DEFAULT '-',
  `state` varchar(55) DEFAULT '-',
  `postal_code` varchar(8) DEFAULT '-',
  `country` varchar(55) DEFAULT '-',
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (4, 'jaya sudha', 'congress', '-', '-', '-', '-', '-', '-', 'nampally', 'hyderbad', 'telangana', '500016', 'India', '99842345346', 'jayasudha@gmail.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (6, 'jagan reddy', 'ysr congress', '-', '-', '-', '-', '-', '-', 'pulivendhula', 'hyderbad', 'telangana', '500016', 'India', '919985922778', 'jagan@gamil.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (7, 'kcr ', 'TRS', '-', '-', '-', '-', '-', '-', 'medak', 'hyderbad', 'telangana', '500016', 'India', '919985922778', 'kcr@gmail.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (8, 'test', 'kkjh', 'klk', 'klkjlk', 'uhuhu', 'huhu', '-fa', '-', 'kljkl', 'klkj', 'lkkjlk', '101100', 'kjlk', '8989898989', 'klkk@kjlk.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (9, 'pradeep Gudipati', 'Met corp IT Solutions Pvt Ltd ', '-', '-', '-', '-', '-', '-', 'banjarahills , road no 2', 'hyderabad', 'telangana', '500016', 'India', '9900095766', 'pradeepgudipati@gmail.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (10, ' Venkatesh Subramani', 'Met corp IT Solutions Pvt Ltd', '-', '-', '-', '-', '-', '-', 'banjarahills , road no 2', 'hyderabad', 'telangana', '500016', 'India', '9740300922', 'venkyy17@gmail.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (11, 'shen', '', '-', '-', '-', '-', '-', '-', '', '', '', '', '', '6774456778', 'fyhftyuh@gmail.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (12, 'CRIPTOCODE INFORMATION TECHNOLOGY SOLUTIONS PRIVATE LIM', 'CRIPTOCODE INFORMATION TECHNOLOGY SOLUTIONS PRIVATE LIMITED', '-', '-', '-', '-', '-', '-', 'Criptocode Information Technology Solutions Private Limited H No-19, Guru Vihar, Near Mukti Dham Chowk, Sarkanda,, Bilaspur - 495006, Chhattisgarh, INDIA', 'hyderabad', 'N/A', '500016', 'India', '8109701669', 'dewanganlakhan@gmail.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (13, 'S.Murali', 'Visualmedia Technologies', '-', '-', '-', '-', '-', '-', '107, G.H.Backside, Mathur. Krishnagiri District,', ' Tamilnadu,, India', 'tamilnadu', ' Pin : 6', 'india', '99430-94945', 'murali@visualmediatech.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (14, 'murali selvaraj', 'Visualmedia Technologies', '-', '-', '-', '-', '-', '-', '107, G.H.Backside, Mathur. Krishnagiri District,', 'Tamilnadu,, India', 'tamilnadu', 'Pin : 63', 'India', '+91-99430-94945', 'murali@visualmediatech.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (15, 'Rectino Technologies ', 'Rectino Technologies ', '-', '-', '-', '-', '-', '-', 'chennai ', 'chennai', 'Tamil nadu ', '500016', 'India', '9944426124', 'ismailcs22@gmail.com');
INSERT INTO customers (`id`, `name`, `company`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`) VALUES (16, 'srividhya marshal tapovan', 'sriVagdevieducational society', '-', '-', '-', '-', '-', '-', 'devarakadra , mahaboobnagar dst', 'telangana , india', 'telengana', 'Pin : 50', '', '+91 905257567', 'vagdevieducationalsociety@yahoo.com');


#
# TABLE STRUCTURE FOR: date_format
#

DROP TABLE IF EXISTS date_format;

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (1, 'mm-dd-yy', 'm-d-Y', '%m-%d-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (2, 'mm/dd/yy', 'm/d/Y', '%m/%d/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (3, 'mm.dd.yy', 'm.d.Y', '%m.%d.%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (4, 'dd-mm-yy', 'd-m-Y', '%d-%m-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (5, 'dd/mm/yy', 'd/m/Y', '%d/%m/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (6, 'dd.mm.yy', 'd.m.Y', '%d.%m.%Y');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS groups;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO groups (`id`, `name`, `description`) VALUES (1, 'admin', 'Administrator');
INSERT INTO groups (`id`, `name`, `description`) VALUES (2, 'sales', 'Sales Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (3, 'viewer', 'View Only User');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (71, '-r<B', 'Varun7king@gmail.com', 1435126454);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (70, '-r<B', 'Varun7king@gmail.com ', 1435126423);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (69, '�RRD', 'varun7king@@gmail.com', 1435126282);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (67, '�RRD', 'varun7king@gmail. com', 1435126204);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (68, '�RRD', 'varun7@gmail.com', 1435126233);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (72, 'swa�', 'varun7king@gmail.com', 1435127003);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (73, 'swa�', 'varun7king@gmail.com', 1435127022);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (74, 'z�d', 'varun7king@gmail.com', 1435127042);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (75, 'z��s', 'varun7king@gmail.com', 1435127062);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (76, 'z�d', 'varun7king@gmail.com', 1435127070);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (77, 'z��s', 'varun7king@gmail.com', 1435127083);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (78, 'z�d', 'varun7king@gmail.com', 1435127133);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (79, 'j3�F', 'varun7king@gmail.com', 1435127166);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (80, 'j3�F', 'varun7king@gmail.com', 1435127186);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (81, '=$�', 'varun7king@gmail.com', 1435127222);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (82, 'z�\\', 'varun7king@gmail.com', 1435127226);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (99, '�h', 'varun7king@gmail.com', 1435131969);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (98, '\'a1', 'Varun7king@gmial.com', 1435131656);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (85, '�I�n', ' varun7king@gmail.com', 1435127463);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (86, '�I�n', 'varun7king@gmail.com', 1435127479);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (101, '1�', ' varun7king@gmail.com', 1435132227);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (88, 'g�J', 'varun7king@gmail.com', 1435127515);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (100, '�h', 'varun7king@gmail.com', 1435131991);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (90, '�S\"+', 'varun7king@gmail.com', 1435127526);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (91, 'g�J', 'varun7king@gmail.com', 1435127536);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (96, '�h', 'test', 1435129106);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (97, '|{��', 'varun7king@gmail.com', 1435131413);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (102, '1�', ' varun7king@gmail.com', 1435132248);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (103, 'g��7', 'arun7king@gmail.com', 1435133342);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (104, 'u���', 'desggn@gmail.com', 1435135620);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (105, 'so��', 'admin', 1435135806);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (106, 'so��', 'admin', 1435135813);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (107, 'so��', 'admin', 1435135817);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (109, '����', 'sefsf@GMA.COM', 1435136305);
INSERT INTO login_attempts (`id`, `ip_address`, `login`, `time`) VALUES (110, '}>ĉ', 'abhishek@bachchan.com', 1435137815);


#
# TABLE STRUCTURE FOR: payment
#

DROP TABLE IF EXISTS payment;

CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `amount` decimal(25,2) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (1, 2, 4, '2014-04-23', 'Paid upon invoice', '67646.23', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (2, 6, 7, '2014-04-23', 'Paid upon invoice', '18121.05', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (3, 7, 4, '2014-04-24', 'Paid upon invoice', '1726728165.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (4, 1, 2, '2014-07-09', NULL, '500.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (5, 8, 6, '2014-08-21', 'Paid upon invoice', '300000.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (6, 5, 6, '2014-11-05', NULL, '98395.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (7, 9, 6, '2014-11-19', 'Paid upon invoice', '123000.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (8, 10, 5, '2014-11-20', 'Paid upon invoice', '5000.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (9, 11, 8, '2014-11-21', 'Paid upon invoice', '110.70', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (10, 18, 3, '2015-02-24', 'Paid upon invoice', '12300.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (11, 19, 15, '2015-04-15', 'Paid upon invoice', '16997.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (12, 21, 4, '2015-06-22', 'Paid upon invoice', '1000.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (13, 22, 4, '2015-06-22', 'Paid upon invoice', '2460.00', 'Admin');
INSERT INTO payment (`id`, `invoice_id`, `customer_id`, `date`, `note`, `amount`, `user`) VALUES (14, 26, 6, '2015-06-24', 'Paid upon invoice', '615.00', 'Admin');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` decimal(25,2) NOT NULL,
  `tax_rate` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO products (`id`, `name`, `price`, `tax_rate`) VALUES (1, 'LED VAN  ( AP 01 4576) ', '30000.00', 2);
INSERT INTO products (`id`, `name`, `price`, `tax_rate`) VALUES (2, 'osram', '25000.00', 1);
INSERT INTO products (`id`, `name`, `price`, `tax_rate`) VALUES (3, 'LED VAN  ( AP 01 5434) ', '30000.00', 3);
INSERT INTO products (`id`, `name`, `price`, `tax_rate`) VALUES (4, 'LED VAN  ( AP 01 4576) ', '30000.00', 2);
INSERT INTO products (`id`, `name`, `price`, `tax_rate`) VALUES (5, 'hms ', '7.00', 1);
INSERT INTO products (`id`, `name`, `price`, `tax_rate`) VALUES (6, 'asdas', '0.00', 1);


#
# TABLE STRUCTURE FOR: quote_items
#

DROP TABLE IF EXISTS quote_items;

CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `tax_rate_id` int(11) NOT NULL,
  `tax` varchar(55) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (1, 1, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (2, 1, 'LED VAN  ( AP 23 5668) ', 2, '23.00%', 1, '25000.00', '25000.00', '5750.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (3, 1, 'BANNER DESIGN & FITTING CHARGES ', 2, '23.00%', 1, '1.00', '1.00', '0.23');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (4, 2, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (5, 2, 'LED VAN  ( AP 23 5668) ', 2, '23.00%', 1, '25000.00', '25000.00', '5750.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (6, 2, 'LED VAN  ( AP 01 5434) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (7, 2, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (8, 3, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (9, 3, 'LED VAN  ( AP 23 5668) ', 2, '23.00%', 1, '25000.00', '25000.00', '5750.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (10, 3, 'LED VAN  ( AP 01 5434) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (11, 3, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (12, 4, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (13, 5, '1 bhk flat ', 1, '0.00', 1, '80.00', '80.00', '0.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (14, 6, 'osram', 1, '0.00', 30, '25000.00', '750000.00', '0.00');
INSERT INTO quote_items (`id`, `quote_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (16, 8, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');


#
# TABLE STRUCTURE FOR: quotes
#

DROP TABLE IF EXISTS quotes;

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  `discount` varchar(20) DEFAULT '0',
  `total_discount` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO quotes (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (1, '123111', 4, 'jaya sudha', '2014-04-23', 'Admin', '', '55001.00', '12650.23', '67646.23', 1, '0.00', '5', '5.00');
INSERT INTO quotes (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (2, '123114', 5, 'vishu vardhan reddy ', '2014-04-23', 'Admin', '', '115000.00', '26450.00', '141445.00', 1, '0.00', '5', '5.00');
INSERT INTO quotes (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (3, '123115', 6, 'jagan reddy', '2014-04-23', 'Admin', '', '115000.00', '26450.00', '141445.00', 1, '0.00', '5', '5.00');
INSERT INTO quotes (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (4, '565775', 6, 'jagan reddy', '2014-04-23', 'Admin', '', '30000.00', '6900.00', '36895.00', 1, '0.00', '5', '5.00');
INSERT INTO quotes (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (5, '333', 4, 'jaya sudha', '2014-05-03', 'Admin', '', '80.00', '0.00', '80.00', 1, '0.00', '0', '0.00');
INSERT INTO quotes (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (6, '0012', 6, 'jagan reddy', '2014-05-26', 'Admin', '', '750000.00', '0.00', '750000.00', 1, '0.00', '0', '0.00');
INSERT INTO quotes (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (8, '43545', 3, 'vijaya reddy ', '2015-02-24', 'Admin', '', '30000.00', '6900.00', '36900.00', 1, '0.00', '0', '0.00');


#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `tax_rate_id` int(11) NOT NULL,
  `tax` varchar(55) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (1, 1, 'yufuyf', 1, '0.00', 3, '222.00', '666.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (2, 1, 'ytdtyd', 2, '23.00%', 3, '222.00', '666.00', '153.18');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (3, 2, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (4, 2, 'LED VAN  ( AP 23 5668) ', 2, '23.00%', 1, '25000.00', '25000.00', '5750.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (5, 2, 'BANNER DESIGN & FITTING CHARGES ', 2, '23.00%', 1, '1.00', '1.00', '0.23');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (6, 3, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (7, 3, 'LED VAN  ( AP 23 5668) ', 2, '23.00%', 1, '25000.00', '25000.00', '5750.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (8, 3, 'LED VAN  ( AP 01 5434) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (9, 3, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (50, 19, 'Tam school manager ', 1, '0.00', 1, '17000.00', '17000.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (49, 18, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '10000.00', '10000.00', '2300.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (12, 5, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '30000.00', '30000.00', '6900.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (13, 5, 'LED VAN  ( AP 23 5668) ', 2, '23.00%', 1, '25000.00', '25000.00', '5750.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (14, 5, 'LED VAN  ( AP 23 5668) ', 2, '23.00%', 1, '25000.00', '25000.00', '5750.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (15, 6, '52 plasma tv ', 2, '23.00%', 2, '5600.00', '11200.00', '2576.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (16, 6, 'tracks', 2, '23.00%', 1, '3535.00', '3535.00', '813.05');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (51, 20, 'school software premium version ', 1, '0.00', 1, '10000.00', '10000.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (20, 8, 'osram', 1, '0.00', 10, '10000.00', '100000.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (21, 9, '12', 2, '23.00%', 1, '100000.00', '100000.00', '23000.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (23, 10, '11K Mobile Track Course', 1, '0.00', 1, '5000.00', '5000.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (24, 11, 'fdsf', 2, '23.00%', 1, '100.00', '100.00', '23.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (53, 22, 'jeans size 32 , t-shirt size : small ', 2, '23.00%', 2, '1000.00', '2000.00', '460.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (28, 13, 'Goods', 1, '0.00', 4, '100.00', '400.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (29, 14, 'monthly', 2, '23.00%', 1, '1500.00', '1500.00', '345.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (30, 15, 'Linux Hosting', 1, '0.00', 100, '750.00', '75000.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (54, 23, 'test kcr', 2, '23.00%', 2, '160.00', '320.00', '73.60');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (55, 24, 'sdsad', 2, '23.00%', 10, '0.00', '0.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (52, 21, 'jeans , size 34 ', 1, '0.00', 1, '1000.00', '1000.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (48, 17, 'LED VAN  ( AP 01 4576) ', 2, '23.00%', 1, '15000.00', '15000.00', '3450.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (56, 25, 'LED VAN  ( AP 01 4576) ', 1, '0.00', 123, '30000.00', '3690000.00', '0.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (57, 25, 'LED VAN  ( AP 01 5434) ', 2, '23.00%', 13, '30000.00', '390000.00', '89700.00');
INSERT INTO sale_items (`id`, `sale_id`, `product_name`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`) VALUES (58, 26, 'sssk', 2, '23.00%', 5, '100.00', '500.00', '115.00');


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'paid',
  `user_id` int(11) NOT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  `discount` varchar(20) DEFAULT '0',
  `total_discount` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (1, '23423235', 2, 'varun remella', '2014-04-09', 'Admin', '', '1332.00', '153.18', '1062.18', 'Partially Paid', 1, '230.00', '423', '423.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (2, '123111', 4, 'jaya sudha', '2014-04-23', 'Admin', '', '55001.00', '12650.23', '67646.23', 'Paid', 1, '0.00', '5', '5.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (3, '123115', 6, 'jagan reddy', '2014-04-23', 'Admin', '', '115000.00', '26450.00', '141445.00', 'Cancelled', 1, '0.00', '5', '5.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (18, '0012', 3, 'vijaya reddy ', '2015-02-24', 'Admin', '', '10000.00', '2300.00', '12300.00', 'Paid', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (5, '123117', 6, 'jagan reddy', '2014-04-23', 'Admin', '', '80000.00', '18400.00', '98395.00', 'Paid', 1, '0.00', '5', '5.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (6, '67567567567', 7, 'kcr ', '2014-04-23', 'Admin', '', '14735.00', '3389.05', '18121.05', 'Paid', 1, '0.00', '3', '3.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (19, '0012', 15, 'Rectino Technologies ', '2015-04-15', 'Admin', '', '17000.00', '0.00', '16997.00', 'Paid', 1, '0.00', '3,000', '3.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (8, 'invoice 1 ', 6, 'jagan reddy', '2014-08-21', 'Admin', '', '100000.00', '0.00', '100000.00', 'Paid', 1, '5.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (9, '10', 6, 'jagan reddy', '2014-11-19', 'Admin', '', '100000.00', '23000.00', '122995.00', 'Paid', 1, '5.00', '5', '5.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (10, '1001', 5, 'vishu vardhan reddy ', '2014-11-20', 'Admin', 'cheque no : 6000', '5000.00', '0.00', '5000.00', 'Cancelled', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (11, 'fsdfe343', 8, 'test', '2014-11-21', 'Admin', '', '100.00', '23.00', '110.70', 'Overdue', 1, '0.00', '10%', '12.30');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (22, 'bahajaa-aa9923932932', 4, 'jaya sudha', '2015-06-22', 'Admin', '', '2000.00', '460.00', '2460.00', 'Paid', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (23, '2345678901', 7, 'kcr ', '2015-06-24', 'Admin', '', '320.00', '73.60', '393.60', 'Overdue', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (13, 'INV2014/12', 4, 'jaya sudha', '2014-12-03', 'Admin', 'nothing', '400.00', '0.00', '395.00', 'Pending', 1, '0.00', '5', '5.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (14, '111', 11, 'shen', '2014-12-04', 'Admin', '', '1500.00', '345.00', '1845.00', 'Pending', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (15, '12', 4, 'jaya sudha', '2014-12-05', 'Admin', 'Need to Pay Annual Basis', '75000.00', '0.00', '75000.00', 'Pending', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (20, '0012', 16, 'srividhya marshal tapovan', '2015-05-25', 'Admin', '', '10000.00', '0.00', '9995.00', 'Paid', 1, '0.00', '5,000', '5.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (17, '43545', 3, 'vijaya reddy ', '2015-02-24', 'Admin', '', '15000.00', '3450.00', '18450.00', 'Pending', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (21, 'vinay - 9983838383', 4, 'jaya sudha', '2015-06-22', 'Admin', '', '1000.00', '0.00', '1000.00', 'Paid', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (24, 'sadasd', 4, 'jaya sudha', '2015-06-24', 'Admin', '', '0.00', '0.00', '0.00', 'Pending', 1, '0.00', '0', '0.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (25, 'w3232323', 4, 'jaya sudha', '2015-06-24', 'Admin', '', '4080000.00', '89700.00', '4169200.00', 'Overdue', 1, '700.00', '500', '500.00');
INSERT INTO sales (`id`, `reference_no`, `customer_id`, `customer_name`, `date`, `user`, `note`, `inv_total`, `total_tax`, `total`, `status`, `user_id`, `shipping`, `discount`, `total_discount`) VALUES (26, 'aaa', 6, 'jagan reddy', '2015-06-24', 'Admin', '', '500.00', '115.00', '615.00', 'Paid', 1, '0.00', 'aaa', '0.00');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `invoice_logo` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `dateformat` tinyint(4) NOT NULL,
  `print_payment` tinyint(4) NOT NULL,
  `calendar` tinyint(4) NOT NULL,
  `restrict_sales` tinyint(4) NOT NULL,
  `major` varchar(25) DEFAULT 'Dollars',
  `minor` varchar(25) DEFAULT 'Cents',
  `display_words` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO settings (`setting_id`, `logo`, `invoice_logo`, `site_name`, `language`, `currency_prefix`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `dateformat`, `print_payment`, `calendar`, `restrict_sales`, `major`, `minor`, `display_words`) VALUES (1, 'logo.png', 'logo1.png', 'noob', 'english', 'INR', 2, 10, 9, 49, 6, 1, 0, 1, 'Rs', 'Cents', 0);


#
# TABLE STRUCTURE FOR: tax_rates
#

DROP TABLE IF EXISTS tax_rates;

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `rate` decimal(4,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (1, 'No Tax', '0.00', '2');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (2, 'VAT', '23.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (3, 'hotel', '12.36', '1');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1, '\0\0', 'Administrator', '580adf7af85ebb7fe396de8cdd4a8c81e5606400', NULL, 'varun7king@gmail.com', NULL, NULL, NULL, NULL, 1351661704, 1435145924, 1, 'Admin', 'Admin', 'Invoice Manager', '0105292122');
INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (2, '1ϮJ', 'ravittheja reddy', '29c2ebdf2aaca87676fa3f8a06da905c3d8c0aa5', NULL, 'ravitheja@gmail.com', NULL, NULL, NULL, NULL, 1398253510, 1398253510, 1, 'ravittheja', 'reddy', 'Led screens pvt ltd ', '919985922778');


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS users_groups;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (1, 1, 1);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (4, 2, 2);
INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (5, 3, 1);


